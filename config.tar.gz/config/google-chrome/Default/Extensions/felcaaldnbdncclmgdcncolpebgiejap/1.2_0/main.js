document.location.href =
    "https://docs.google.com/spreadsheets?usp=chrome_app&authuser=0";
